import 'package:get/get_navigation/src/routes/get_route.dart';

import '../../common_widgets/bottom_navigation_bar/bottom_navigation_view.dart';
import '../modules/home/views/expand_screen.dart';
import '../modules/login/views/login_view.dart';
import '../modules/login/views/otp_validation_screen.dart';
import '../modules/regester_village/views/picklist_view.dart';
import '../modules/register/views/register_view.dart';
import '../modules/splash/views/splash_view.dart';

class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String otp = '/otp';
  static const String register = '/register';
  static const String bottomMain = '/bottomMain';
  static const String registerVillage = '/registerVillage';
  static const String expandInfo = '/expandInfo';



  static List<GetPage> getPages = [
    GetPage(name: login, page: () => const LoginView()),
    GetPage(name: register, page: () => RegisterView()),
    GetPage(name: bottomMain, page: () => BottomMainBar()),
    GetPage(name: splash, page: () => SplashView()),
    GetPage(name: otp, page: () => OtpValidationScreenView()),
    GetPage(name: register, page: () => ViewPickList()),
    GetPage(name: expandInfo, page: () => ExpandScreen()),


  ];
}

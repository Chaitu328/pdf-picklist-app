import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../../../app_data/api_url.dart';
import '../../../../app_data/base_api_service.dart';
import '../../login/controllers/login_controller.dart';
import '../models/get_pick_list_model.dart';

class RegisterVillageController extends GetxController {
  final _apiService = ApiService();
  final loginController = Get.put(LoginController());

  final villageName = TextEditingController().obs;
  final aboutController = TextEditingController().obs;
  final localityController = TextEditingController().obs;
  final stateController = TextEditingController().obs;
  final villagePin = TextEditingController().obs;
  final villageLocalityController = TextEditingController().obs;

  // Error text variables
  final villageNameError = RxString("");
  final aboutError = RxString("");
  final villagePinError = RxString("");
  final villageLocalityError = RxString("");
  final stateError = RxString("");
  final villageState = RxString("");

  // Pick lists
  final pickLists = <PickListModel>[].obs;
  final isLoading = false.obs;
  final errorMessage = RxString("");

  @override
  void onInit() {
    super.onInit();
    fetchPickLists();
  }

  Future<void> fetchPickLists() async {
    try {
      isLoading.value = true;
      errorMessage.value = "";

      final response = await _apiService.getRaw(ApiConstants.getPickList);

      if (response != null && response.statusCode == 200) {
        final data = response.data as List<dynamic>;
        pickLists.value = data
            .map((item) => PickListModel.fromJson(item as Map<String, dynamic>))
            .toList();
      } else {
        errorMessage.value = "Failed to load pick lists.";
      }
    } catch (e) {
      errorMessage.value = "Something went wrong: $e";
    } finally {
      isLoading.value = false;
    }
  }

  bool validate() {
    bool isValid = true;

    villageNameError.value = '';
    villageLocalityError.value = '';
    villagePinError.value = '';
    stateError.value = '';
    aboutError.value = '';

    if (villageName.value.text.isEmpty) {
      villageNameError.value = 'Village name cannot be empty';
      isValid = false;
    }
    if (stateController.value.text.isEmpty) {
      stateError.value = 'State cannot be empty';
      isValid = false;
    }
    if (aboutController.value.text.isEmpty) {
      aboutError.value = 'About cannot be empty';
      isValid = false;
    }
    if (villageLocalityController.value.text.isEmpty) {
      villageLocalityError.value = 'Locality cannot be empty';
      isValid = false;
    }
    if (villagePin.value.text.isEmpty) {
      villagePinError.value = 'Pin cannot be empty';
      isValid = false;
    }

    if (isValid) registerVillage();
    return isValid;
  }

  void registerVillage() {
    villageName.value.text = "";
    villagePin.value.text = "";
    villageLocalityController.value.text = "";
    aboutController.value.text = "";
    stateController.value.text = "";
  }

  @override
  void onClose() {
    villageName.value.dispose();
    aboutController.value.dispose();
    localityController.value.dispose();
    stateController.value.dispose();
    villagePin.value.dispose();
    villageLocalityController.value.dispose();
    super.onClose();
  }
}
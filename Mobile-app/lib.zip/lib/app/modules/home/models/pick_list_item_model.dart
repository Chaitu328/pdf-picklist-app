// models/pick_list_model.dart

class PickListItem {
  final String sNo;
  final String partNumber;
  final String description;
  final String hsnNo;
  final String moq;
  final String stockOnHand;
  final String mrp;
  final String orderQty;
  final String allocatedQty;
  final String pickedQty;
  final String binL1;
  final String binL2;
  final String binL3;

  PickListItem({
    required this.sNo,
    required this.partNumber,
    required this.description,
    required this.hsnNo,
    required this.moq,
    required this.stockOnHand,
    required this.mrp,
    required this.orderQty,
    required this.allocatedQty,
    required this.pickedQty,
    required this.binL1,
    required this.binL2,
    required this.binL3,
  });

  factory PickListItem.fromRow(List<dynamic> row) {
    return PickListItem(
      sNo: (row[0] ?? '').toString().trim(),
      binL1: (row[1] ?? '').toString().trim(),
      binL2: (row[2] ?? '').toString().replaceAll('\n', '-').trim(),
      binL3: (row[3] ?? '').toString().trim(),
      partNumber: (row[4] ?? '').toString().replaceAll('\n', '').trim(),
      description: (row[5] ?? '').toString().replaceAll('\n', ' ').trim(),
      hsnNo: (row[6] ?? '').toString().trim(),
      moq: (row[7] ?? '').toString().trim(),
      stockOnHand: (row[8] ?? '').toString().trim(),
      mrp: (row[9] ?? '').toString().trim(),
      orderQty: (row[10] ?? '').toString().trim(),
      allocatedQty: (row[11] ?? '').toString().trim(),
      pickedQty: (row[12] ?? '').toString().trim(),
    );
  }
}

class PickListData {
  final String pickListNo;
  final String pickListDate;
  final String orderNo;
  final String orderDate;
  final String code;
  final String name;
  final String city;
  final List<PickListItem> items;

  PickListData({
    required this.pickListNo,
    required this.pickListDate,
    required this.orderNo,
    required this.orderDate,
    required this.code,
    required this.name,
    required this.city,
    required this.items,
  });
}
class PickListModel {
  final String id;
  final String pickListNo;
  final ClientWorkerInfo? clientId;
  final ClientWorkerInfo? workerId;
  final String status;
  final List<PartModel> parts;
  final DateTime createdAt;

  PickListModel({
    required this.id,
    required this.pickListNo,
    this.clientId,
    this.workerId,
    required this.status,
    required this.parts,
    required this.createdAt,
  });

  factory PickListModel.fromJson(Map<String, dynamic> json) {
    return PickListModel(
      id: json['_id'] as String? ?? '',
      pickListNo: json['pick_list_no'] as String? ?? '',
      clientId: json['clientId'] != null
          ? ClientWorkerInfo.fromJson(json['clientId'] as Map<String, dynamic>)
          : null,
      workerId: json['workerId'] != null
          ? ClientWorkerInfo.fromJson(json['workerId'] as Map<String, dynamic>)
          : null,
      status: json['status'] as String? ?? 'unassigned',
      parts: (json['parts'] as List<dynamic>?)
          ?.map((e) => PartModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
          [],
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'pick_list_no': pickListNo,
    'clientId': clientId?.toJson(),
    'workerId': workerId?.toJson(),
    'status': status,
    'parts': parts.map((e) => e.toJson()).toList(),
    'createdAt': createdAt.toIso8601String(),
  };
}

class ClientWorkerInfo {
  final String id;
  final String email;

  ClientWorkerInfo({
    required this.id,
    required this.email,
  });

  factory ClientWorkerInfo.fromJson(Map<String, dynamic> json) {
    return ClientWorkerInfo(
      id: json['_id'] as String? ?? '',
      email: json['email'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'email': email,
  };
}

class PartModel {
  final String id;
  final String partno;
  final String description;
  final int reqQty;
  final int alloQty;
  final String status;

  PartModel({
    required this.id,
    required this.partno,
    required this.description,
    required this.reqQty,
    required this.alloQty,
    required this.status,
  });

  factory PartModel.fromJson(Map<String, dynamic> json) {
    return PartModel(
      id: json['_id'] as String? ?? '',
      partno: json['partno'] as String? ?? '',
      description: json['description'] as String? ?? '',
      reqQty: (json['req_qty'] as num?)?.toInt() ?? 0,
      alloQty: (json['allo_qty'] as num?)?.toInt() ?? 0,
      status: json['status'] as String? ?? 'pending',
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'partno': partno,
    'description': description,
    'req_qty': reqQty,
    'allo_qty': alloQty,
    'status': status,
  };
}
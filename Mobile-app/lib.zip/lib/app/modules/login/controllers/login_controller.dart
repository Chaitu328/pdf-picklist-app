import 'dart:async';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:inventory/app_data/api_url.dart';
import '../../../../app_utils/color_constants.dart';
import '../../../routes/app_routes.dart';
import 'package:inventory/app_data/base_api_service.dart';
import '../../../../main.dart';

class LoginController extends GetxController {
  final emailController = TextEditingController().obs;
  final passwordController = TextEditingController().obs;
  final emailError = RxString("");
  final passwordError = RxString("");
  final otpController = RxString("");
  final isPasswordVisible = false.obs;
  RxBool isResendEnabled = false.obs;
  RxString timerText = '30s'.obs; // Timer display string
  late Timer _timer;
  int _remainingTime = 30; // 30 seconds timer

  // Loading state
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
  }

  // Validate inputs
  void validate() {
    emailError.value = "";
    passwordError.value = "";

    // Validate email
    if (!GetUtils.isEmail(emailController.value.text)) {
      emailError.value = 'Invalid email address';
    }

    // Validate password
    if (passwordController.value.text.isEmpty) {
      passwordError.value = 'Password is required';
    } else if (passwordController.value.text.length < 6) {
      passwordError.value = 'Password must be at least 6 characters';
    }

    if (emailError.value.isEmpty && passwordError.value.isEmpty) {
      // Proceed with your logic (e.g., move to next screen)
    }
  }

  // Toggle password visibility
  void togglePasswordVisibility() {
    isPasswordVisible.value = !isPasswordVisible.value;
  }

  // Navigate to the registration screen
  void goToRegister() {
    Get.toNamed(AppRoutes.register);
  }

  // Start the OTP timer countdown
  void startTimer() {
    _remainingTime = 30; // Reset to 30 seconds
    isResendEnabled.value = false; // Disable resend initially
    timerText.value = '$_remainingTime s';

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingTime == 0) {
        _timer.cancel();
        isResendEnabled.value = true; // Enable resend when timer ends
        timerText.value = 'Resend OTP now';
      } else {
        _remainingTime--;
        timerText.value = '$_remainingTime s'; // Update timer text
      }
    });
  }

  // Verify OTP (triggered on button press)
  void verifyOtp1(BuildContext context) {
   // print('Verifying OTP: ${otpController.value}');
    // Your OTP verification logic goes here
  }

  // Function to handle OTP resend
  void resendOtp(context) {
    if (isResendEnabled.value) {
      startTimer(); // Restart the timer when resend OTP is pressed
      showSnackBar(
        context,
        'OTP Resent Successfully!',
         AppColor.bottomNavBarBackground,
        Colors.white,
      );
    }
  }

  // Handle OTP verification
  void verifyOtp(BuildContext context) {
    if (otpController.value == "1212") {
      Get.offAllNamed(AppRoutes.bottomMain); // Navigate to the next screen
      showSnackBar(
        context,
        'OTP Verified',
        Colors.green,
        Colors.white,
      );
    } else {
      showSnackBar(
        context,
        'OTP verification failed',
        Colors.red,
        Colors.white,
      );
    }
  }

  // Email and password verification
  Future<void> verifyEmailPassword(BuildContext context) async {
    isLoading.value = true;
    try {
      String email = emailController.value.text.trim();
      String password = passwordController.value.text.trim();

      // Validate inputs
      validate();

      // If validation passes, proceed to login
      if (emailError.value.isEmpty && passwordError.value.isEmpty) {
        final apiService = ApiService();
        final response = await apiService.postWithoutAuth(ApiConstants.loginEndPoint, {
          "email": email,
          "password": password
        });
        if (response == null) {
          showSnackBar(
            context,
            'Network error: Unable to connect to server',
            Colors.red,
            Colors.white,
          );
        } else if (response.statusCode == 200) {
          // Assuming response.data is a map with 'token'
          final data = response.data;
          if (data != null && data['token'] != null) {
            box.write("user_token", data['token']);
            Get.offAllNamed(AppRoutes.bottomMain);
            showSnackBar(
              context,
              'Login successful',
              Colors.green,
              Colors.white,
            );
          } else {
            showSnackBar(
              context,
              'Invalid response: no token received',
              Colors.red,
              Colors.white,
            );
          }
        } else {
          showSnackBar(
            context,
            'Login failed: ${response.statusCode} - ${response.statusMessage ?? 'Unknown error'}',
            Colors.red,
            Colors.white,
          );
        }
      }
    } catch (e) {
      showSnackBar(
        context,
        'An error occurred: ${e.toString()}',
        Colors.red,
        Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // Utility function to show SnackBar
  void showSnackBar(BuildContext context, String message,
      Color backgroundColor, Color textColor) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: Duration(seconds: 2),
        content: Text(
          message,
          style: TextStyle(
            color: textColor,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: backgroundColor,
      ),
    );
  }

  @override
  void onClose() {
    super.onClose();
    _timer.cancel(); // Cancel the timer when the controller is disposed
  }
}

import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../../../app_utils/color_constants.dart';
import '../../../routes/app_routes.dart';
import '../controllers/profile_controller.dart';

class ProfileView extends GetView<ProfileController> {
  @override
  Widget build(BuildContext context) {

    final ProfileController controller = Get.put(ProfileController());
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: AppColor.cAppPrimaryColor, // Set the status bar color
      statusBarIconBrightness: Brightness.light, // Light icons for dark backgrounds
      systemNavigationBarColor: AppColor.cAppPrimaryColor, // Custom navigation bar color
      systemNavigationBarIconBrightness: Brightness.light, // Light icons for navigation bar
    ));

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: AppColor.bottomNavBarBackground, // Custom AppBar color
        title: const Text(
          'Settings',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 18.0,
            color: AppColor.whiteColor,
          ),
        ),
      ),
      body: Container(
        // decoration: const BoxDecoration(
        //   image: DecorationImage(
        //     image: AssetImage('assets/images/app_bg.png'), // Set your background image here
        //     fit: BoxFit.cover,
        //   ),
        // ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile information or avatar section can go here
             // Padding(
               // padding: const EdgeInsets.symmetric(vertical: 8.0),
                // child: Row(
                //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //   children: [
                //     CircleAvatar(
                //       radius: 50.0,
                //       backgroundImage:
                //       NetworkImage('https://image.civitai.com/xG1nkqKTMzGDvpLrqFT7WA/7d2a57d4-23ee-4ccf-b34c-bd6ddbb1f4a8/width=1200/7d2a57d4-23ee-4ccf-b34c-bd6ddbb1f4a8.jpeg/'),
                //       backgroundColor: Colors.transparent,
                //     ),
                //     Text("Siddarth Roy",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16))
                //   ],
                // )
              //),
             // const SizedBox(height: 16),

              // List of settings and options
              Expanded(
                child: ListView(
                  children: [
                    ListTile(
                      leading: Icon(Icons.lock, color: AppColor.colorAccent),
                      title: Text('Privacy Settings', style: TextStyle(fontSize: 18.0)),
                      onTap: () {
                        // Navigate to Privacy settings
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.notifications, color: AppColor.colorAccent),
                      title: Text('Notification Preferences', style: TextStyle(fontSize: 18.0)),
                      onTap: () {
                        // Navigate to Notification settings
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.language, color: AppColor.colorAccent),
                      title: Text('Language', style: TextStyle(fontSize: 18.0)),
                      onTap: () {
                        // Navigate to Language settings
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.help, color: AppColor.colorAccent),
                      title: Text('Help & Support', style: TextStyle(fontSize: 18.0)),
                      onTap: () {
                        // Navigate to Help & Support section
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.logout, color: AppColor.colorAccent),
                      title: Text('Log Out', style: TextStyle(fontSize: 18.0)),
                      onTap: () {
                        Get.offAllNamed(AppRoutes.login);
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

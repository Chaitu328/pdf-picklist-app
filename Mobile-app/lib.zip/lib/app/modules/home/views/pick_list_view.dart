// views/pick_list_view.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:inventory/app_utils/color_constants.dart';
import 'package:read_pdf_text/read_pdf_text.dart';
import 'package:file_picker/file_picker.dart';

import '../../../../app_data/api_url.dart';
import '../../../../app_data/base_api_service.dart';

class PickListItem {
  final String sNo;
  final String partNumber;
  final String description;
  final String hsnNo;
  final String moq;
  final String stockOnHand;
  final String mrp;
  final String orderQty;
  final String allocatedQty;
  final String pickedQty;

  PickListItem({
    required this.sNo,
    required this.partNumber,
    required this.description,
    required this.hsnNo,
    required this.moq,
    required this.stockOnHand,
    required this.mrp,
    required this.orderQty,
    required this.allocatedQty,
    this.pickedQty = '',
  });
}

class PickListData {
  final String pickListNo;
  final String pickListDate;
  final String orderNo;
  final String orderDate;
  final List<PickListItem> items;

  PickListData({
    required this.pickListNo,
    required this.pickListDate,
    required this.orderNo,
    required this.orderDate,
    required this.items,
  });
}

class PdfExtractionService {
  static Future<PickListData?> extractPickListData(File pdfFile) async {
    try {
      final String fullText = await ReadPdfText.getPDFtext(pdfFile.path);
      if (fullText.trim().isEmpty) return null;
      return _parsePickListText(fullText);
    } catch (e, st) {
      debugPrint('PDF extraction error: $e\n$st');
      return null;
    }
  }

  static PickListData _parsePickListText(String text) {
    final lines = text
        .replaceAll('\r\n', '\n')
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    String pickListNo = '', pickListDate = '', orderNo = '', orderDate = '';

    for (final line in lines) {
      _matchFirst(line, RegExp(r'Pick\s+List\s+No\s+(\S+)'),
              (v) { if (pickListNo.isEmpty) pickListNo = v; });
      _matchFirst(line, RegExp(r'Pick\s+List\s+Date\s+(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})'),
              (v) { if (pickListDate.isEmpty) pickListDate = v; });
      _matchFirst(line, RegExp(r'Order\s+No\s+(\S+)'),
              (v) { if (orderNo.isEmpty) orderNo = v; });
      _matchFirst(line, RegExp(r'Order\s+Date\s+(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})'),
              (v) { if (orderDate.isEmpty) orderDate = v; });
    }

    return PickListData(
      pickListNo: pickListNo,
      pickListDate: pickListDate,
      orderNo: orderNo,
      orderDate: orderDate,
      items: _parseTableRows(lines),
    );
  }

  static void _matchFirst(String line, RegExp re, void Function(String) setter) {
    final m = re.firstMatch(line);
    if (m != null) setter(m.group(1)!);
  }

  static List<PickListItem> _parseTableRows(List<String> lines) {
    int tableStart = -1;
    for (int i = 0; i < lines.length; i++) {
      if (lines[i].contains('Part Number') && lines[i].contains('Description')) {
        tableStart = i + 2;
        break;
      }
    }
    if (tableStart == -1) return [];

    final rowStartRe = RegExp(r'^\d+\s');
    final footerRe   = RegExp(r'^(Picked By|Checked By|Packed By|Remarks)');
    final List<String> mergedRows = [];
    String buf = '';

    for (int i = tableStart; i < lines.length; i++) {
      final line = lines[i];
      if (footerRe.hasMatch(line)) break;
      if (rowStartRe.hasMatch(line)) {
        if (buf.isNotEmpty) mergedRows.add(_norm(buf));
        buf = line;
      } else if (buf.isNotEmpty) {
        buf += ' $line';
      }
    }
    if (buf.isNotEmpty) mergedRows.add(_norm(buf));

    final hsnRe = RegExp(
      r'(\d{8})\s+(\d+)\s+(\d+)\s+([\d,\.]+)\s+(\d+)\s+(\d+)',
    );

    final List<String> pairedRows = [];
    int idx = 0;
    while (idx < mergedRows.length) {
      final row = mergedRows[idx];
      if (hsnRe.hasMatch(row)) {
        pairedRows.add(row);
        idx++;
      } else {
        if (idx + 1 < mergedRows.length) {
          pairedRows.add('$row ${mergedRows[idx + 1]}');
          idx += 2;
        } else {
          idx++;
        }
      }
    }

    final partCandidateRe = RegExp(r'[A-Z0-9]{8,}');
    final hasLetterRe     = RegExp(r'[A-Z]');
    final hasDigitRe      = RegExp(r'[0-9]');
    final List<PickListItem> items = [];

    for (final row in pairedRows) {
      final hm = hsnRe.firstMatch(row);
      if (hm == null) continue;

      final hsn      = hm.group(1)!;
      final moq      = hm.group(2)!;
      final stock    = hm.group(3)!;
      final mrp      = hm.group(4)!;
      final orderQty = hm.group(5)!;
      final allocQty = hm.group(6)!;

      final prefix   = row.substring(0, hm.start).trim();
      final snoMatch = RegExp(r'^(\d+)\s+').firstMatch(prefix);
      final sno      = snoMatch?.group(1) ?? '';
      final afterSno = snoMatch != null ? prefix.substring(snoMatch.end).trim() : prefix;

      final tokens  = afterSno.split(RegExp(r'\s+'));
      int skipCount = 0;
      for (final tok in tokens) {
        if (tok.length < 8) { skipCount++; } else { break; }
      }

      String partNumber = '';
      for (int t = skipCount; t < tokens.length; t++) {
        final m = partCandidateRe.firstMatch(tokens[t]);
        if (m != null && hasLetterRe.hasMatch(m.group(0)!) && hasDigitRe.hasMatch(m.group(0)!)) {
          partNumber = m.group(0)!;
          break;
        }
      }
      if (partNumber.isEmpty) continue;

      final partStart = row.indexOf(partNumber);
      String description = '';
      if (partStart != -1) {
        description = row
            .substring(partStart + partNumber.length, hm.start)
            .trim()
            .replaceAll(RegExp(r'(\s+[A-Z0-9]{1,3}){1,3}$'), '')
            .trim();
      }

      items.add(PickListItem(
        sNo: sno, partNumber: partNumber, description: description,
        hsnNo: hsn, moq: moq, stockOnHand: stock, mrp: mrp,
        orderQty: orderQty, allocatedQty: allocQty,
      ));
    }

    return items;
  }

  static String _norm(String s) => s.replaceAll(RegExp(r'\s+'), ' ').trim();
}

class PickListView extends StatefulWidget {
  const PickListView({Key? key}) : super(key: key);
  @override
  State<PickListView> createState() => _PickListViewState();
}

class _PickListViewState extends State<PickListView> {
  static const _primary = AppColor.primaryButtonColor;
  final apiService = ApiService();

  bool _isLoading = false;
  String _errorMsg = '';
  PickListData? _data;

  final _plNoCtrl   = TextEditingController();
  final _plDateCtrl = TextEditingController();
  final _onCtrl     = TextEditingController();
  final _odCtrl     = TextEditingController();
  List<Map<String, TextEditingController>> _rows = [];

  @override
  void dispose() {
    _plNoCtrl.dispose(); _plDateCtrl.dispose();
    _onCtrl.dispose();   _odCtrl.dispose();
    _disposeRows();
    super.dispose();
  }

  void _disposeRows() {
    for (final r in _rows) for (final c in r.values) c.dispose();
    _rows = [];
  }

  Future<void> _pickAndExtract() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: ['pdf', 'PDF'],
    );
    if (result == null || result.files.single.path == null) return;

    setState(() { _isLoading = true; _errorMsg = ''; });

    final data = await PdfExtractionService.extractPickListData(
      File(result.files.single.path!),
    );

    if (!mounted) return;

    if (data == null || data.items.isEmpty) {
      setState(() {
        _isLoading = false;
        _errorMsg = data == null
            ? 'Failed to read PDF.'
            : 'No table rows found in PDF.';
      });
      return;
    }

    _disposeRows();

    // ✅ Build new rows BEFORE calling setState
    final newRows = data.items.map((item) => {
      'sNo':          TextEditingController(text: item.sNo),
      'partNumber':   TextEditingController(text: item.partNumber),
      'description':  TextEditingController(text: item.description),
      'hsnNo':        TextEditingController(text: item.hsnNo),
      'moq':          TextEditingController(text: item.moq),
      'stockOnHand':  TextEditingController(text: item.stockOnHand),
      'mrp':          TextEditingController(text: item.mrp),
      'orderQty':     TextEditingController(text: item.orderQty),
      'allocatedQty': TextEditingController(text: item.allocatedQty),
    }).toList();

    debugPrint('✅ Total items parsed: ${newRows.length}');

    // ✅ Set ALL state in a single setState so Flutter rebuilds everything at once
    setState(() {
      _data        = data;
      _rows        = newRows;
      _isLoading   = false;
      _errorMsg    = '';
    });

    _plNoCtrl.text   = data.pickListNo;
    _plDateCtrl.text = data.pickListDate;
    _onCtrl.text     = data.orderNo;
    _odCtrl.text     = data.orderDate;
  }

  void _clear() {
    _disposeRows();
    setState(() { _data = null; _errorMsg = ''; });
    _plNoCtrl.clear(); _plDateCtrl.clear();
    _onCtrl.clear();   _odCtrl.clear();
  }

  Future<void> _save() async {
    if (_rows.isEmpty) return;

    final List<Map<String, dynamic>> parts = _rows.map((r) => {
      "partno":       r['partNumber']!.text,
      "description":  r['description']!.text,
      "req_qty":      int.tryParse(r['orderQty']!.text) ?? 0,
    }).toList();

    final Map<String, dynamic> body = {
      "pick_list_no": _plNoCtrl.text,
      "parts":        parts,
    };

    debugPrint('Uploading pick list: $body');

    setState(() => _isLoading = true);

    try {
      final response = await apiService.postRaw(
        ApiConstants.postToPickList,
        body,
      );

      if (!mounted) return;

      if (response == null) {
        _showSnack('Network error: Unable to connect to server', Colors.red);
      } else if (response.statusCode == 200 || response.statusCode == 201) {
        _showSnack(
          'Pick list "${_plNoCtrl.text}" saved — ${parts.length} parts uploaded',
          Colors.green.shade700,
        );
        _clear();
      } else {
        _showSnack(
          'Upload failed: ${response.statusCode} — ${response.statusMessage ?? 'Unknown error'}',
          Colors.red,
        );
      }
    } catch (e) {
      if (mounted) _showSnack('Error: ${e.toString()}', Colors.red);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F8),
      appBar: AppBar(
        title: const Text('Pick List', style: TextStyle(fontWeight: FontWeight.w700)),
        backgroundColor: AppColor.bottomNavBarBackground,
        foregroundColor: Colors.white,
        centerTitle: true,
        actions: [
          if (_data != null)
            IconButton(icon: const Icon(Icons.refresh), onPressed: _clear, tooltip: 'Clear'),
        ],
      ),

      // ── ALWAYS-VISIBLE SAVE BUTTON AT BOTTOM ──────────────────────────────
      bottomNavigationBar: _data != null && !_isLoading
          ? SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 3,
              ),
              onPressed: _save,
              icon: const Icon(Icons.save, size: 20),
              label: Text(
                'Save Pick List  (${_rows.length} items)',
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
      )
          : null,
      // ──────────────────────────────────────────────────────────────────────

      body: _isLoading
          ? const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: _primary),
            SizedBox(height: 16),
            Text('Processing…', style: TextStyle(color: Colors.black54)),
          ],
        ),
      )
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _bigBtn(
              label: _data == null
                  ? 'Upload Pick List PDF'
                  : 'Upload Another PDF',
              icon: Icons.upload_file,
              color: Colors.green.shade800,
              onTap: _pickAndExtract,
            ),
            if (_errorMsg.isNotEmpty) _errorBanner(_errorMsg),
            if (_data != null) ...[
              const SizedBox(height: 20),
              _card(
                title: 'Pick List Details',
                icon: Icons.receipt_long,
                child: Column(children: [
                  Row(children: [
                    Expanded(child: _lf('Pick List No',   _plNoCtrl,   readOnly: true)),
                    const SizedBox(width: 12),
                    Expanded(child: _lf('Pick List Date', _plDateCtrl, readOnly: true)),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: _lf('Order No',   _onCtrl, readOnly: true)),
                    const SizedBox(width: 12),
                    Expanded(child: _lf('Order Date', _odCtrl, readOnly: true)),
                  ]),
                ]),
              ),
              const SizedBox(height: 16),
              _card(
                title: 'Items (${_rows.length})',
                icon: Icons.list_alt,
                child: ListView.builder(
                  key: ValueKey(_rows.length), // ✅ forces full rebuild when count changes
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _rows.length,
                  itemBuilder: (context, index) => _itemCard(index),
                ),
              ),
              // Extra bottom padding so last card isn't hidden behind the
              // sticky Save button
              const SizedBox(height: 80),
            ],
            if (_data == null && _errorMsg.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 60),
                child: Center(
                  child: Column(children: [
                    Icon(Icons.picture_as_pdf_outlined,
                        size: 80, color: Colors.grey.shade400),
                    const SizedBox(height: 16),
                    Text(
                      'Upload a GST Pick List PDF\nto auto-fill the fields below',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 15,
                          color: Colors.grey.shade500,
                          height: 1.5),
                    ),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _itemCard(int i) {
    final r = _rows[i];
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: i.isEven ? const Color(0xFFEEF1FB) : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFDDE3F0)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _badge(r['sNo']!.text),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Part: ${r['partNumber']!.text}',
              style: const TextStyle(
                  fontWeight: FontWeight.w700, fontSize: 14, color: _primary),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        // Description — read-only
        _lf('Description', r['description']!, readOnly: true),
        const SizedBox(height: 8),
        // HSN Code & MOQ — read-only
        Row(children: [
          Expanded(child: _lf('HSN Code', r['hsnNo']!,
              type: TextInputType.number, readOnly: true)),
          const SizedBox(width: 12),
          Expanded(child: _lf('MOQ', r['moq']!,
              type: TextInputType.number, readOnly: true)),
        ]),
        const SizedBox(height: 8),
        // Stock on Hand & MRP — read-only
        Row(children: [
          Expanded(child: _lf('Stock on Hand', r['stockOnHand']!,
              type: TextInputType.number, readOnly: true)),
          const SizedBox(width: 12),
          Expanded(child: _lf('MRP', r['mrp']!,
              type: TextInputType.number, readOnly: true)),
        ]),
        const SizedBox(height: 8),
        // Order Qty & Allocated Qty — read-only
        Row(children: [
          Expanded(child: _lf('Order Qty', r['orderQty']!,
              type: TextInputType.number, hi: true, readOnly: true)),
          const SizedBox(width: 12),
          Expanded(child: _lf('Allocated Qty', r['allocatedQty']!,
              type: TextInputType.number, hi: true, readOnly: true)),
        ]),
      ]),
    );
  }

  Widget _badge(String label) => Container(
    width: 28, height: 28,
    decoration: BoxDecoration(
        color: _primary, borderRadius: BorderRadius.circular(6)),
    alignment: Alignment.center,
    child: Text(label,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold)),
  );

  Widget _bigBtn({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) =>
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
          onPressed: onTap,
          icon: Icon(icon),
          label: Text(label,
              style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w600)),
        ),
      );

  Widget _card({
    required String title,
    required IconData icon,
    required Widget child,
  }) =>
      Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(children: [
              Icon(icon, color: _primary, size: 20),
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: _primary)),
            ]),
          ),
          const Divider(height: 1),
          Padding(padding: const EdgeInsets.all(16), child: child),
        ]),
      );

  Widget _errorBanner(String msg) => Padding(
    padding: const EdgeInsets.only(top: 12),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.red.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.red.shade200)),
      child: Text(msg,
          style: TextStyle(color: Colors.red.shade700, fontSize: 13)),
    ),
  );

  /// A labelled field.
  /// [readOnly] = true  → grey background, no keyboard, no cursor interaction
  /// [hi]       = true  → highlighted styling (blue tint) for important fields
  Widget _lf(
      String label,
      TextEditingController ctrl, {
        TextInputType type = TextInputType.text,
        bool hi = false,
        bool readOnly = false,
      }) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label.toUpperCase(),
            style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: Colors.grey.shade600,
                letterSpacing: 0.6)),
        const SizedBox(height: 4),
        TextFormField(
          controller: ctrl,
          keyboardType: type,
          readOnly: readOnly,
          // Hide cursor on read-only fields for a cleaner look
          showCursor: !readOnly,
          style: TextStyle(
              fontSize: 13,
              fontWeight: hi ? FontWeight.w700 : FontWeight.normal,
              color: readOnly
                  ? Colors.black54
                  : hi
                  ? _primary
                  : Colors.black87),
          decoration: InputDecoration(
            isDense: true,
            contentPadding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            filled: true,
            fillColor: readOnly
                ? const Color(0xFFEEEEEE)   // grey for read-only
                : hi
                ? const Color(0xFFE8EAF6)
                : const Color(0xFFFAFAFA),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                    color: readOnly
                        ? Colors.grey.shade400
                        : hi
                        ? const Color(0xFF5C6BC0)
                        : Colors.grey.shade300)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                    color: readOnly
                        ? Colors.grey.shade400
                        : hi
                        ? const Color(0xFF5C6BC0)
                        : Colors.grey.shade300)),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                    color: readOnly ? Colors.grey.shade400 : _primary,
                    width: readOnly ? 1.0 : 1.5)),
          ),
        ),
      ]);
}
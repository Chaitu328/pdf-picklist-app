class ApiConstants {
  ///QA Environment Base Url

  /// Production Environment Base Url
  static const String baseURL = "https://pick-list.onrender.com/api";

  ///End points
  static const String loginEndPoint = "$baseURL/login";
  static const String registrationEndPoint = "$baseURL/register";
  static const String postToPickList = "$baseURL/picklist";
  static const String getPickList = "$baseURL/picklist/";
}

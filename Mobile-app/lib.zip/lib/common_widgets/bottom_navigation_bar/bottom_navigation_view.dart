import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../app/modules/home/views/home_view.dart';
import '../../app/modules/home/views/pick_list_view.dart';
import '../../app/modules/profile/views/profile_view.dart';
import '../../app/modules/regester_village/views/picklist_view.dart';
import '../../app_utils/color_constants.dart';
import 'bottom_navigation_controller.dart';

class BottomMainBar extends StatelessWidget {
  final NavigationController navController = Get.put(NavigationController());

  BottomMainBar({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: AppColor.cAppPrimaryColor,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColor.cAppPrimaryColor,
      systemNavigationBarIconBrightness: Brightness.light,
    ));

    final List<_NavItem> navItems = [
      _NavItem(icon: Icons.home_rounded, label: 'Home'),
      _NavItem(icon: Icons.list_alt_rounded, label: 'Pick List'),
      _NavItem(icon: Icons.inventory_2_rounded, label: 'View List'),
      _NavItem(icon: Icons.person_rounded, label: 'Profile'),
    ];

    return Obx(() {
      return Scaffold(
        extendBody: true,
        body: IndexedStack(
          index: navController.currentIndex.value,
          children: [
            HomeView(),
            PickListView(),
            ViewPickList(),
            ProfileView(),
          ],
        ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: AppColor.cAppPrimaryColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 20,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 65,
              child: Row(
                children: List.generate(navItems.length, (index) {
                  final isSelected =
                      navController.currentIndex.value == index;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => navController.changeTab(index),
                      behavior: HitTestBehavior.opaque,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.easeInOut,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Pill indicator + icon
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              curve: Curves.easeInOut,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 5),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? Colors.white.withOpacity(0.18)
                                    : Colors.transparent,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Icon(
                                navItems[index].icon,
                                size: isSelected ? 21 : 18,
                                color: isSelected
                                    ? Colors.white
                                    : Colors.white.withOpacity(0.5),
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              navItems[index].label,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                                color: isSelected
                                    ? Colors.white
                                    : Colors.white.withOpacity(0.5),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      );
    });
  }
}

class _NavItem {
  final IconData icon;
  final String label;

  _NavItem({required this.icon, required this.label});
}